'use client'

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useLocaleStore } from '@/store/locale-store'

const languages = [
  { code: 'uz' as const, flag: '🇺🇿' },
  { code: 'ru' as const, flag: '🇷🇺' },
]

export function LanguageSwitcher() {
  const { locale, setLocale } = useLocaleStore()
  const current = languages.find(l => l.code === locale) || languages[0]

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          className="flex items-center justify-center w-9 h-9 rounded-lg text-base hover:bg-gray-100 transition-colors focus:outline-none"
          aria-label={`Til: ${locale}`}
        >
          {current.flag}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-0">
        {languages.map((lang) => (
          <DropdownMenuItem
            key={lang.code}
            onClick={() => setLocale(lang.code)}
            className={`justify-center text-lg px-3 ${locale === lang.code ? 'bg-gray-100' : ''}`}
          >
            {lang.flag}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
